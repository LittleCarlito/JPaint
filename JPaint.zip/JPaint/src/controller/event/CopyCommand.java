package controller.event;

import java.util.List;

import controller.interfaces.IMouseEvent;
import controller.singletons.ListOutput;
import model.interfaces.IShape;
import view.interfaces.PaintCanvasBase;

public class CopyCommand implements IMouseEvent {
	
	private PaintCanvasBase paintCanvas;
	
	public CopyCommand(PaintCanvasBase paintCanvas) {
		this.paintCanvas = paintCanvas;
	}

	@Override
	public void execute() {
		paintCanvas.clearClip();
		List<IShape> selectList = paintCanvas.getSelect();
		List<IShape> clipList = paintCanvas.getClip();
		ListOutput.execute(selectList, (IShape shape) -> {clipList.add(shape);});
	}

}
