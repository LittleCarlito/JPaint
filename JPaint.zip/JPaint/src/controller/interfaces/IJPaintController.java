package controller.interfaces;

public interface IJPaintController {
    void setup();
}
