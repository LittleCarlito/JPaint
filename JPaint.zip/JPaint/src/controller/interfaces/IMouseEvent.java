package controller.interfaces;

public interface IMouseEvent {
	public void Execute();
}
