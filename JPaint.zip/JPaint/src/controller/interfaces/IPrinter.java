package controller.interfaces;

public interface IPrinter {
	public void print();
}
