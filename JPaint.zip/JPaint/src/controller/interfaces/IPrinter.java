package controller.interfaces;

import model.interfaces.IShape;

public interface IPrinter {
	public void print(IShape shape);
}
