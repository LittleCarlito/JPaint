package controller.interfaces;

import model.interfaces.IShape;

public interface IShapeCommand {
	public void execute(IShape o);
}
